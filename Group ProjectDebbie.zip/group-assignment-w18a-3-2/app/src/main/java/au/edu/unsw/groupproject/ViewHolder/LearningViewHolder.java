package au.edu.unsw.groupproject.ViewHolder;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import au.edu.unsw.groupproject.R;

public class LearningViewHolder extends RecyclerView.ViewHolder {

    public ImageView imageView;
    public TextView textView;

    public LearningViewHolder(@NonNull View itemView) {
        super(itemView);

        imageView = itemView.findViewById(R.id.imageView);
        textView = itemView.findViewById(R.id.textView);

    }
}
