package au.edu.unsw.groupproject.Adapters;

import android.content.Context;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import au.edu.unsw.groupproject.ViewHolder.LearningViewHolder;

public class LearningAdapter extends RecyclerView.Adapter<LearningViewHolder> {

    @NonNull
    @Override
    public LearningViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return null;
    }

    @Override
    public void onBindViewHolder(@NonNull LearningViewHolder holder, int position) {

    }

    @Override
    public int getItemCount() {
        return 0;
    }
}
