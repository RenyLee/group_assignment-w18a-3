package au.edu.unsw.groupproject.Interface;

public interface InterestRateInterface {

    void onItemClick(String rate, String name, String lastupdate);
}

