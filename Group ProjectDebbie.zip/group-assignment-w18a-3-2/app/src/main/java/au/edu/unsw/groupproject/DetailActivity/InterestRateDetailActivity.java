package au.edu.unsw.groupproject.DetailActivity;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import java.util.ArrayList;

import au.edu.unsw.groupproject.R;

public class InterestRateDetailActivity extends AppCompatActivity {

    TextView ArateTV,AnameTV,AlastupdateTV;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_interest_rate_detail);

        Intent i = getIntent();

        String name = i.getStringExtra("name");
        ArrayList<String> rate = (ArrayList<String>) i.getStringArrayListExtra("rate");
        String lastupdate = i.getStringExtra("lastupdate");

        ArateTV = findViewById(R.id.rateTV);
        AlastupdateTV = findViewById(R.id.lastupdateTV);
        AnameTV = findViewById(R.id.nameTV);

        ArateTV.setText(String.valueOf(rate));
        AnameTV.setText(name);
        AlastupdateTV.setText(lastupdate);



    }
}