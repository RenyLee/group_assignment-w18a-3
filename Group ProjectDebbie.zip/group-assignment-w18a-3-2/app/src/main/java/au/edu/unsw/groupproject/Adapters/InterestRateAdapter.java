package au.edu.unsw.groupproject.Adapters;

import static android.content.ContentValues.TAG;

import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import au.edu.unsw.groupproject.DetailActivity.InterestRateDetailActivity;
import au.edu.unsw.groupproject.InterestRateDM;
import au.edu.unsw.groupproject.Interface.InterestRateInterface;
import au.edu.unsw.groupproject.Interface.InterestRateInterface;
import au.edu.unsw.groupproject.R;

public class InterestRateAdapter extends RecyclerView.Adapter<InterestRateAdapter.MyViewHolder> {


    private ArrayList<InterestRateDM> mInterestRate;
    private InterestRateInterface rInterface;


    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_interestrate,parent,false);

        return new MyViewHolder(v,rInterface);

    }

    public InterestRateAdapter(ArrayList<InterestRateDM> mInterestRate, InterestRateInterface rvinterface) {

        this.mInterestRate = mInterestRate;
        this.rInterface = rvinterface;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        final InterestRateDM mPosition = mInterestRate.get(position);

        holder.rowNameTV.setText(mPosition.getName());
        //holder.levelBtn.setText(mPosition.getDifficulty());
        //holder.typeBtn.setText(mPosition.getType());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                System.out.println(mPosition.getRate());
                System.out.println(mPosition.getLastupdate());

                Intent i = new Intent(view.getContext(), InterestRateDetailActivity.class);

                i.putExtra("name",mPosition.getName());
                i.putStringArrayListExtra("ingredients", (ArrayList<String>) mPosition.getRate());
                i.putExtra("instructions",mPosition.getLastupdate());

                view.getContext().startActivity(i);

            }
        });

    }

    @Override
    public int getItemCount() {
        return mInterestRate.size();
    }

    public interface RecyclerViewClickListener{
        void onClick(View view, int position);
    }


    public class MyViewHolder extends RecyclerView.ViewHolder {

        //private RecyclerViewClickListener mListener;
        public TextView rowNameTV;
        public Button levelBtn;
        public Button typeBtn;

        public MyViewHolder(@NonNull View itemView, InterestRateInterface rvIn) {
            super(itemView);


            Log.d(TAG, "On Click Working!");
            rowNameTV = itemView.findViewById(R.id.rowNameTV);
            //levelBtn = itemView.findViewById(R.id.levelBtn);
            //typeBtn = itemView.findViewById(R.id.typeBtn);
        }
    }

    public void setData(ArrayList<InterestRateDM> data) {
        mInterestRate.clear();
        mInterestRate.addAll(data);
        //notifyDataSetChanged();
    }
}