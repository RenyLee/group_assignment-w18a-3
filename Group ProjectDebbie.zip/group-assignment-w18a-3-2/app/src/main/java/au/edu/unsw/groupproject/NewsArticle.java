package au.edu.unsw.groupproject;

import com.google.gson.annotations.SerializedName;

public class NewsArticle {

    @SerializedName("title")
    private String title;

    @SerializedName("urlToImage")
    private String imageUrl;

    // Getters and Setters

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }
}
