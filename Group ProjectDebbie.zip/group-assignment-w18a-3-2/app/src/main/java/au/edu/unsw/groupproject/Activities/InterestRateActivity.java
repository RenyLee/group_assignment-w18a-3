package au.edu.unsw.groupproject.Activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.widget.SearchView;
import android.widget.Toast;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import au.edu.unsw.groupproject.Adapters.InterestRateAdapter;
import au.edu.unsw.groupproject.InterestRateDM;
import au.edu.unsw.groupproject.Interface.InterestRateInterface;
import au.edu.unsw.groupproject.R;

public class InterestRateActivity extends AppCompatActivity {

    InterestRateAdapter adapter;
    RecyclerView interestrateRV;

    InterestRateInterface recyclerViewInterface;

    SearchView searchView;

    RecyclerView.LayoutManager layoutManager;

    List<InterestRateDM> InterestRateDMList;

    ExecutorService executor = Executors.newSingleThreadExecutor();

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_interest_rate);

        searchView = findViewById(R.id.searchView);
        interestrateRV = findViewById(R.id.interestrateRV);

        layoutManager = new LinearLayoutManager(this);

        interestrateRV.setLayoutManager(layoutManager);

        adapter = new InterestRateAdapter(new ArrayList<InterestRateDM>(), recyclerViewInterface);

        interestrateRV.setAdapter(adapter);

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {

                if(s == null || s.isEmpty()) {

                    Toast.makeText(InterestRateActivity.this, "Please write something into the search bar!", Toast.LENGTH_LONG).show();

                }
                executor.execute(new Runnable() {
                    @Override
                    public void run() {

                        try{

                            URL url = new URL("https://api.api-ninjas.com/v1/inflation?country=" + s);
                            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                            connection.setRequestProperty("X-Api-Key","qx68WBsjeQ+qUMkZ8fijjw==dwVKmErOKP3JMINk");
                            connection.setRequestProperty("accept", "application/json");
                            InputStream responseStream = connection.getInputStream();
                            ObjectMapper mapper = new ObjectMapper();
                            JsonNode root = mapper.readTree(responseStream);
                            System.out.println(root);
                            String searchChecker = String.valueOf(root);

                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    if(searchChecker.equals("[]") || searchChecker.isEmpty() || searchChecker == null ) {
                                        Toast.makeText(InterestRateActivity.this, "No Search Results Returned!", Toast.LENGTH_LONG).show();



                                    } else {

                                        adapter.notifyDataSetChanged();


                                        Toast.makeText(InterestRateActivity.this, "Returning Top 10 Results!", Toast.LENGTH_LONG).show();

                                    }
                                }
                            });

                            InterestRateDMList = mapper.readValue(String.valueOf(root),new TypeReference<List<InterestRateDM>>() {});
                            adapter.setData((ArrayList<InterestRateDM>) InterestRateDMList);

                        } catch(Exception e) {
                            Log.d("TAG", String.valueOf(e));
                        }

                    }
                });

                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                return false;
            }
        });
    }
}