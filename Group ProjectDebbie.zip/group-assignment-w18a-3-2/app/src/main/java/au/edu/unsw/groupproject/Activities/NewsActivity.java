package au.edu.unsw.groupproject.Activities;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

import au.edu.unsw.groupproject.Adapters.NewsAdapter;
import au.edu.unsw.groupproject.Interface.NewsInterface;
import au.edu.unsw.groupproject.NewsArticle;
import au.edu.unsw.groupproject.NewsResponse;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import au.edu.unsw.groupproject.R;

public class NewsActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private NewsAdapter newsAdapter;
    private List<NewsArticle> articles;

    private static final String BASE_URL = "https://newsapi.org/v2/top-headlines?";
    private static final String COUNTRY = "au";
    private static final String CATEGORY = "business";
    private static final String API_KEY = "f3bde91b29994b5bb58caaa28ec22f82";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Initialize Retrofit
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        NewsInterface newsApiClient = retrofit.create(NewsInterface.class);

        // Make API call
        Call<NewsResponse> call = newsApiClient.getTopHeadlines(COUNTRY, CATEGORY, API_KEY);
        call.enqueue(new Callback<NewsResponse>() {
            @Override
            public void onResponse(Call<NewsResponse> call, Response<NewsResponse> response) {
                if (response.isSuccessful()) {
                    articles = response.body().getArticles();
                    newsAdapter = new NewsAdapter(articles);
                    recyclerView.setAdapter(newsAdapter);
                }
            }

            @Override
            public void onFailure(Call<NewsResponse> call, Throwable t) {
                // Handle API call failure
            }
        });
    }
}